FINAL UPDATED VERSION
तुमचा स्वतःचा लोगो, तुमची गाडी आणि तुमचा UPI QR code HTML मध्येच embed केले आहेत.
म्हणून ZIP मधून index.html उघडल्यावरही ते दिसतील.
Call: 9307764442
WhatsApp: 9011491713
Email: tejaspisal1434@gmail.com
Location: मंगळवार पेठ, कराड, महाराष्ट्र - 415124
UPI ID: tejaspisal94101@ybl
